﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Maticsoft.Web 三层结构示例源码")]
[assembly: AssemblyDescription("Maticsoft.Web 三层结构示例源码")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Maticsoft")]
[assembly: AssemblyProduct("Maticsoft.Web 三层结构示例源码")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.0.0.0")]