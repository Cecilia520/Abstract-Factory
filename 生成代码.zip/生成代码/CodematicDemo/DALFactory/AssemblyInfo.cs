﻿using System.Reflection;
[assembly: AssemblyTitle("Maticsoft.Web 三层结构示例源码")]
[assembly: AssemblyDescription("动软三层架构项目示例源码")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Maticsoft")]
[assembly: AssemblyProduct("动软三层架构项目示例源码")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.0.0.0")]


