﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// CourseTable:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class CourseTable
	{
		public CourseTable()
		{}
		#region Model
		private string _courseid;
		private string _coursename;
		private string _point;
		private DateTime _stunumber;
		/// <summary>
		/// 
		/// </summary>
		public string CourseID
		{
			set{ _courseid=value;}
			get{return _courseid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string CourseName
		{
			set{ _coursename=value;}
			get{return _coursename;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Point
		{
			set{ _point=value;}
			get{return _point;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime StuNumber
		{
			set{ _stunumber=value;}
			get{return _stunumber;}
		}
		#endregion Model

	}
}

