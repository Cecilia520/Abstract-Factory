﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// TeacherTable1:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class TeacherTable1
	{
		public TeacherTable1()
		{}
		#region Model
		private string _teacherid;
		private string _teachername;
		private string _teachersex;
		private DateTime? _teacherbirthday;
		private string _post;
		private string _department;
		/// <summary>
		/// 
		/// </summary>
		public string TeacherID
		{
			set{ _teacherid=value;}
			get{return _teacherid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TeacherName
		{
			set{ _teachername=value;}
			get{return _teachername;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TeacherSex
		{
			set{ _teachersex=value;}
			get{return _teachersex;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? TeacherBirthday
		{
			set{ _teacherbirthday=value;}
			get{return _teacherbirthday;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Post
		{
			set{ _post=value;}
			get{return _post;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Department
		{
			set{ _department=value;}
			get{return _department;}
		}
		#endregion Model

	}
}

