﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.ScoreTable
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				string CourseID = "";
				if (Request.Params["id0"] != null && Request.Params["id0"].Trim() != "")
				{
					CourseID= Request.Params["id0"];
				}
				string StudentID = "";
				if (Request.Params["id1"] != null && Request.Params["id1"].Trim() != "")
				{
					StudentID= Request.Params["id1"];
				}
				#warning 代码生成提示：显示页面,请检查确认该语句是否正确
				ShowInfo(CourseID,StudentID);
			}
		}
			
	private void ShowInfo(string CourseID,string StudentID)
	{
		Maticsoft.BLL.ScoreTable bll=new Maticsoft.BLL.ScoreTable();
		Maticsoft.Model.ScoreTable model=bll.GetModel(CourseID,StudentID);
		this.lblCourseID.Text=model.CourseID;
		this.lblStudentID.Text=model.StudentID;
		this.txtScore.Text=model.Score.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(!PageValidate.IsNumber(txtScore.Text))
			{
				strErr+="Score格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string CourseID=this.lblCourseID.Text;
			string StudentID=this.lblStudentID.Text;
			int Score=int.Parse(this.txtScore.Text);


			Maticsoft.Model.ScoreTable model=new Maticsoft.Model.ScoreTable();
			model.CourseID=CourseID;
			model.StudentID=StudentID;
			model.Score=Score;

			Maticsoft.BLL.ScoreTable bll=new Maticsoft.BLL.ScoreTable();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
