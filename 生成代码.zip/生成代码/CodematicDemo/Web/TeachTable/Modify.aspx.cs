﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.TeachTable
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				string CourseID = "";
				if (Request.Params["id0"] != null && Request.Params["id0"].Trim() != "")
				{
					CourseID= Request.Params["id0"];
				}
				string TeacherID = "";
				if (Request.Params["id1"] != null && Request.Params["id1"].Trim() != "")
				{
					TeacherID= Request.Params["id1"];
				}
				#warning 代码生成提示：显示页面,请检查确认该语句是否正确
				ShowInfo(CourseID,TeacherID);
			}
		}
			
	private void ShowInfo(string CourseID,string TeacherID)
	{
		Maticsoft.BLL.TeachTable bll=new Maticsoft.BLL.TeachTable();
		Maticsoft.Model.TeachTable model=bll.GetModel(CourseID,TeacherID);
		this.lblCourseID.Text=model.CourseID;
		this.lblTeacherID.Text=model.TeacherID;
		this.txtLocation.Text=model.Location.ToString();

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(!PageValidate.IsNumber(txtLocation.Text))
			{
				strErr+="Location格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string CourseID=this.lblCourseID.Text;
			string TeacherID=this.lblTeacherID.Text;
			int Location=int.Parse(this.txtLocation.Text);


			Maticsoft.Model.TeachTable model=new Maticsoft.Model.TeachTable();
			model.CourseID=CourseID;
			model.TeacherID=TeacherID;
			model.Location=Location;

			Maticsoft.BLL.TeachTable bll=new Maticsoft.BLL.TeachTable();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
