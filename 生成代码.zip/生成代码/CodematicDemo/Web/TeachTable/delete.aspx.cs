﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Maticsoft.Web.TeachTable
{
    public partial class delete : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            			if (!Page.IsPostBack)
			{
				Maticsoft.BLL.TeachTable bll=new Maticsoft.BLL.TeachTable();
				string CourseID = "";
				if (Request.Params["id0"] != null && Request.Params["id0"].Trim() != "")
				{
					CourseID= Request.Params["id0"];
				}
				string TeacherID = "";
				if (Request.Params["id1"] != null && Request.Params["id1"].Trim() != "")
				{
					TeacherID= Request.Params["id1"];
				}
				#warning 代码生成提示：删除页面,请检查确认传递过来的参数是否正确
				// bll.Delete(CourseID,TeacherID);
			}

        }
    }
}